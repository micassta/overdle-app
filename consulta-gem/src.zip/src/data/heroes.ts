// Este archivo simula nuestra base de datos de héroes.

import tracerAvatar from '../assets/tracer.png';
import reinhardtAvatar from '../assets/reinhardt.png';
import mercyAvatar from '../assets/mercy.png';
import genjiAvatar from '../assets/genji.png';
import sojournAvatar from '../assets/sojourn.png';
import soldadoAvatar from '../assets/soldado.png';

export type Hero = {
  id: number;
  name: string;
  avatarUrl: string; // URL de la imagen pequeña del héroe
};

// Exportamos nuestra lista de héroes de prueba
export const heroes: Hero[] = [
  { id: 1, name: 'Tracer', avatarUrl: tracerAvatar },
  { id: 2, name: 'Reinhardt', avatarUrl: reinhardtAvatar },
  { id: 3, name: 'Mercy', avatarUrl: mercyAvatar },
  { id: 4, name: 'Genji', avatarUrl: genjiAvatar },
  { id: 5, name: 'Sojourn', avatarUrl: sojournAvatar },
  { id: 6, name: 'Soldado: 76', avatarUrl: soldadoAvatar },
  // acá van más heroes, pero pues es una simulación
];
